import connexion
import six

from swagger_server import util


def get_delete(path):  # noqa: E501
    """Del

     # noqa: E501

    :param path: 
    :type path: str

    :rtype: None
    """
    return 'do some magic!'


def get_list():  # noqa: E501
    """LIST

     # noqa: E501


    :rtype: None
    """
    return 'do some magic!'
