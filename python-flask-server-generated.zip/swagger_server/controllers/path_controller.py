import connexion
import six

from swagger_server import util


def get_copy_bucket_path(bucket_path):  # noqa: E501
    """Copy

     # noqa: E501

    :param bucket_path: 
    :type bucket_path: str

    :rtype: None
    """
    return 'do some magic!'
